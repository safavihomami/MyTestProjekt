package at.bfi.oop.object_klasse.circle;

public class Circle_2 {

	
	protected int radius, posX, posY;
	protected boolean filled;
	
	
	public Circle_2(int radius, int posX, int posY, boolean filled) {
		
		this.radius = radius;
		this.posX = posX;
		this.posY = posY;
		this.filled = filled;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (filled ? 1231 : 1237);
		result = prime * result + posX;
		result = prime * result + posY;
		result = prime * result + radius;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Circle_2 other = (Circle_2) obj;
		if (filled != other.filled)
			return false;
		if (posX != other.posX)
			return false;
		if (posY != other.posY)
			return false;
		if (radius != other.radius)
			return false;
		return true;
	}


	
	
	/*
	
	// Wurde in einer Klasse equals ueberschrieben(wie in dieser Klasse hier!), so sollte
	//hashcode so ueberschrieben werden , dass zwei GLEICHE OBJEKTE gleiche HASHCODE haben
	//Achtung: Zwei VERSCHIEDENE OBJEKTE duerfen GLEICHE HASHCODE haben. 
	//
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (filled ? 1231 : 1237);
		result = prime * result + posX;
		result = prime * result + posY;
		result = prime * result + radius;
		return result;
	}

	/*
	 * Uebrpruepungen beim equal():
	 * 
	 * 1) check if> this == obj => wenn true liefert, es handelt sich um ein und dasselbe Objekt
	 * 
	 * 2) check if> Sind beide Objekte zur Laufzeit exakt vom gleichen Typ> dann via getClass() -Methode testen
	 * 
	 *  3) Die Objekte einer Subklasse kann mit einem Objekt der Superklasse verglichen werden 
	 *  	, mittels instanceof (Sinnvoll wenn subklasse keine eigene Attributen deklariert, und nur
	 *  	die Methoden der Superklasse ueberschreibt.
	 *  
	 *  4) Am Ende werden alle Attributen Werte der beiden Objekten verglichen
	 *  
	 *  und dann folgende checks:
	 *  
	 * reflexive: ∀ x, x.equals(x) == true
      symmetric: ∀ x y, x.equals(y) ⇔ y.equals(x)
      transitive: ∀ x y, x.equals(y) and y.equals(z) ⇔ x.equals(z)
      consistent: for any x e y multiple invocations of x.equals(y) always returns the same value if no information about x and y used in equals() is modified
       ∀ x not null, x.equals(null) == false

	 */
/*
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Circle_2 other = (Circle_2) obj;
		if (filled != other.filled)
			return false;
		if (posX != other.posX)
			return false;
		if (posY != other.posY)
			return false;
		if (radius != other.radius)
			return false;
		return true;
	}
	
	*/
}
