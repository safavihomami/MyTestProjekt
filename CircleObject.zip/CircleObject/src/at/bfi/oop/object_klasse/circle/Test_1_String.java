package at.bfi.oop.object_klasse.circle;

//Hashcode -Methode liefert einen ganzzahligen Wert, den so genannten Hashcode,
		//Hashcode wird fuer die Speicherung von Objekten in HashTabellen gebraucht.
		//HashTabellen beeinhalten Key , value -Paaren , wobei die Objekte werden als Key gespeichert  
		//Hierbei wird zu jedem Objekt eine Value = "ein Integer -Wert" zugeordnet.
		//HashCode erzeugt dieser Integerwert(ein Speicherplatznummer)
		//
		//Vertrag oder Bedingung fuer dise Vorgangsweise:
		//Die Klassen dieser Objekte muessen die Methoden
		//@equals() und 
		//@hashcode() in
		//geeigneter Form implementieren.
		//
//equals -Methode:
		//Der Eintrag und der Zugriff auf "Key" erfolgt intern mit Hilfe der Methode> @equals()
		//Viele Klassen ueberschreiben @equals() -Methode, um die "Gleichheit von Objekten" 
		//anwendungsspezifisch zu implementieren>
		//Dazu nutzen sie die Werte Ihrer Instanzvariablen.
		 //Die Ueberschreibender Methode sollte die folgenden Eigenschaften haben:
		// siehe Test_2_CircleHash.java fuer die checkliste von equals


public class Test_1_String {

	public static void main(String[] args) {
		
		//equal() von Object vergleicht die Adressen ==> hier die Gleichheit bedeutet gleiche Adressen,==
		//Object o1 = new Object();
		//Object o2 = o1;
		//System.out.println(o1.equals(o2));
		//
		//		
		String str1 = new String("Helmut");
	
		String str2 = new String("Helmuti");
		//
		System.out.println(str1.equals(str2));
		//HashCode -Vertrag
		//equal objects must have equal hash codes.
		//d.h. Die Objekte , die wir vergleichen wollen, muessen gleiche HashCode haben
	System.out.println("Hashcode str1: " + str1.hashCode());
	System.out.println("Hashcode str2: " + str2.hashCode());
				
		/*
		//oder so
		String s1 = "Helmut";
		String s2 = "Helmut";
		//
		System.out.println(s1.equals(s2));
		System.out.println("Hashcode s1: " + s1.hashCode());
		System.out.println("Hashcode s2: " + s2.hashCode());
		*/	

	}

}
