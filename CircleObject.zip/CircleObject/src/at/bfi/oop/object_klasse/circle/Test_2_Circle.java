package at.bfi.oop.object_klasse.circle;

public class Test_2_Circle {

	public static void main(String[] args) {
		
		Circle c1 = new Circle(1, 10, 20, true);
		Circle c2 = new Circle(1, 10, 20, true);
			
		//HashCode -Vertrag
		//equal objects must have equal hash codes.
		//d.h. Die Objekte , die wir vergleichen wollen, muessen gleiche HashCode haben
		System.out.println("Hashcode c1: " + c1.hashCode());
		System.out.println("Hashcode c2: " + c2.hashCode());
		//Wie man hier sieht, die beide Objekten hier haben verschiedene hashcodes
		//, obwohl beide Objekten gleiche werte besitzen
		//
		// Was muss man nun hier machen?
		// sehen Sie, wie ich das Problem in Circle_2 -Klasse geloest habe
		// zum Testen von Circle_2.java schaue Test_3_Circle_2.java
		
		System.out.println(c1.equals(c2));
		
				
	}

}
