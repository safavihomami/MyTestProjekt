package at.bfi.oop.object_klasse.circle;

public class Circle {
	
	protected int radius, posX, posY;
	protected boolean filled;
	
	
	public Circle(int radius, int posX, int posY, boolean filled) {
		
		this.radius = radius;
		this.posX = posX;
		this.posY = posY;
		this.filled = filled;
	}

	
}
